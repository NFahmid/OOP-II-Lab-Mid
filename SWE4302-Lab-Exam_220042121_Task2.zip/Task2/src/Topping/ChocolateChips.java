package Topping;

public class ChocolateChips extends Topping {
    public ChocolateChips() {
        super("Chocolate Chips", 0.50);
    }
}

