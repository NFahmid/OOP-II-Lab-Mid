package Topping;

public class Marshmallow extends Topping {
    public Marshmallow() {
        super("Marshmallow", 0.70);
    }
}

