package Topping;

public class Sprinkles extends Topping {
    public Sprinkles() {
        super("Sprinkles", 0.30);
    }
}

// Similar classes for Marshmallow, CrushedOreo, FreshStrawberries, ChocolateChips

