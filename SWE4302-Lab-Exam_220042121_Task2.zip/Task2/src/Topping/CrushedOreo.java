package Topping;

public class CrushedOreo extends Topping {
    public CrushedOreo() {
        super("Crushed Oreo", 0.85);
    }
}

