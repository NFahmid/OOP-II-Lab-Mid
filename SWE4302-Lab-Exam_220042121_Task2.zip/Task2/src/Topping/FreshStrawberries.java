package Topping;

public class FreshStrawberries extends Topping {
    public FreshStrawberries() {
        super("Fresh Strawberries", 1.00);
    }
}

