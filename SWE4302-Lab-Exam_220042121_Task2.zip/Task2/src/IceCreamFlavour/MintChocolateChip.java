package IceCreamFlavour;

public class MintChocolateChip extends IceCreamFlavor {
    public MintChocolateChip() {
        super("Mint Chocolate Chip", 2.80);
    }
}
