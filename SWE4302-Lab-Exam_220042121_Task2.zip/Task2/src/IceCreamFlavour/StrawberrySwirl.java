package IceCreamFlavour;

public class StrawberrySwirl extends IceCreamFlavor {
    public StrawberrySwirl() {
        super("Strawberry Swirl", 2.75);
    }
}

