package IceCreamFlavour;

public class PistachioDelight extends IceCreamFlavor {
    public PistachioDelight() {
        super("Pistachio Delight", 3.25);
    }
}