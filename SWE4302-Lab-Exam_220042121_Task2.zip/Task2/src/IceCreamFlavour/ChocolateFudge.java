package IceCreamFlavour;

public class ChocolateFudge extends IceCreamFlavor {
    public ChocolateFudge() {
        super("ChocolateFudge", 3.00);
    }
}
