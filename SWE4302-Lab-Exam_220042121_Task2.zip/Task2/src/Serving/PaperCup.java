package Serving;

public class PaperCup extends Serving {
    public PaperCup() {
        super("Paper Cup", 0.00);
    }
}
