package Serving;

public class WaffleCone extends Serving {
    public WaffleCone() {
        super("Waffle Cone", 5.00);
    }
}
